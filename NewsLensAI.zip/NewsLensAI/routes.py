from flask import render_template, request, redirect, url_for, flash, jsonify
from database import db
from models import NewsStory, Feedback, StoryCategory
from ai_analysis import SentimentAnalyzer
from datetime import datetime
import logging
import os
import csv
import io
from werkzeug.utils import secure_filename

logger = logging.getLogger(__name__)

# Initialize sentiment analyzer
sentiment_analyzer = SentimentAnalyzer()

def register_routes(app):
    """Register all routes with the Flask app"""

    @app.route('/')
    def index():
        """Home page with story list and search functionality"""
        search_query = request.args.get('search', '')
        category_filter = request.args.get('category', '')
        region_filter = request.args.get('region', '')

        # Base query
        query = NewsStory.query

        # Apply filters
        if search_query:
            query = query.filter(
                db.or_(
                    NewsStory.title.contains(search_query),
                    NewsStory.content.contains(search_query),
                    NewsStory.author.contains(search_query)
                )
            )

        if category_filter:
            query = query.filter(NewsStory.category == category_filter)

        if region_filter:
            query = query.filter(NewsStory.region == region_filter)

        # Get stories with pagination
        page = request.args.get('page', 1, type=int)
        stories = query.order_by(NewsStory.date_published.desc()).paginate(
            page=page, per_page=12, error_out=False
        )

        # Get filter options
        categories = db.session.query(NewsStory.category).distinct().all()
        regions = db.session.query(NewsStory.region).distinct().all()

        return render_template('index.html',
                             stories=stories,
                             search_query=search_query,
                             category_filter=category_filter,
                             region_filter=region_filter,
                             categories=[c[0] for c in categories],
                             regions=[r[0] for r in regions])

    @app.route('/story/<int:story_id>')
    def story_detail(story_id):
        """Story detail page with feedback display"""
        story = NewsStory.query.get_or_404(story_id)
        feedbacks = Feedback.query.filter_by(story_id=story_id).order_by(Feedback.date_created.desc()).all()

        # Get AI insights
        insights = sentiment_analyzer.get_feedback_insights(feedbacks)

        return render_template('story_detail.html', story=story, feedbacks=feedbacks, insights=insights)

    @app.route('/submit-story', methods=['GET', 'POST'])
    def submit_story():
        """Submit a new news story"""
        if request.method == 'POST':
            try:
                # Handle file uploads
                main_image_path = ''
                thumbnail_path = ''
                gallery_image_path = ''

                # Create upload directory if it doesn't exist
                upload_folder = 'static/uploads'
                if not os.path.exists(upload_folder):
                    os.makedirs(upload_folder)

                # Process main image
                if 'main_image' in request.files:
                    main_image = request.files['main_image']
                    if main_image and main_image.filename != '':
                        main_filename = secure_filename(main_image.filename)
                        main_image_path = f'uploads/{main_filename}'
                        main_image.save(os.path.join('static', main_image_path))

                # Process thumbnail
                if 'thumbnail' in request.files:
                    thumbnail = request.files['thumbnail']
                    if thumbnail and thumbnail.filename != '':
                        thumb_filename = secure_filename(thumbnail.filename)
                        thumbnail_path = f'uploads/{thumb_filename}'
                        thumbnail.save(os.path.join('static', thumbnail_path))

                # Process gallery image
                if 'gallery_image' in request.files:
                    gallery_image = request.files['gallery_image']
                    if gallery_image and gallery_image.filename != '':
                        gallery_filename = secure_filename(gallery_image.filename)
                        gallery_image_path = f'uploads/{gallery_filename}'
                        gallery_image.save(os.path.join('static', gallery_image_path))

                story = NewsStory(
                    title=request.form['title'],
                    content=request.form['content'],
                    author=request.form['author'],
                    publication=request.form['publication'],
                    category=request.form['category'],
                    region=request.form['region'],
                    url=request.form.get('url', ''),
                    image_url=request.form.get('image_url', ''),
                    main_image=main_image_path,
                    thumbnail=thumbnail_path,
                    gallery_image=gallery_image_path,
                    date_published=datetime.strptime(request.form['date_published'], '%Y-%m-%d') if request.form.get('date_published') else datetime.utcnow()
                )

                db.session.add(story)
                db.session.commit()

                flash('Story submitted successfully!', 'success')
                return redirect(url_for('story_detail', story_id=story.id))

            except Exception as e:
                logger.error(f"Error submitting story: {e}")
                flash('Error submitting story. Please try again.', 'error')
                db.session.rollback()

        return render_template('submit_story.html')

    @app.route('/story/<int:story_id>/feedback', methods=['GET', 'POST'])
    def submit_feedback(story_id):
        """Submit feedback for a story"""
        story = NewsStory.query.get_or_404(story_id)

        if request.method == 'POST':
            try:
                comment = request.form.get('comment', '')

                # Perform enhanced sentiment analysis on the comment
                sentiment_score, sentiment_label, confidence, details = sentiment_analyzer.analyze_sentiment(comment)

                feedback = Feedback(
                    story_id=story_id,
                    accuracy_rating=int(request.form['accuracy_rating']),
                    bias_rating=int(request.form['bias_rating']),
                    relevance_rating=int(request.form['relevance_rating']),
                    local_impact_rating=int(request.form['local_impact_rating']),
                    comment=comment,
                    reviewer_name=request.form.get('reviewer_name', ''),
                    reviewer_email=request.form.get('reviewer_email', ''),
                    reviewer_location=request.form.get('reviewer_location', ''),
                    sentiment_score=sentiment_score,
                    sentiment_label=sentiment_label
                )

                db.session.add(feedback)
                db.session.commit()

                flash('Thank you for your feedback!', 'success')
                return redirect(url_for('story_detail', story_id=story_id))

            except Exception as e:
                logger.error(f"Error submitting feedback: {e}")
                flash('Error submitting feedback. Please try again.', 'error')
                db.session.rollback()

        return render_template('feedback_form.html', story=story)

    @app.route('/dashboard')
    def dashboard():
        """Analytics dashboard for news organizations"""
        # Get overall statistics
        total_stories = NewsStory.query.count()
        total_feedback = Feedback.query.count()

        # Get recent stories with feedback counts
        stories_with_feedback = db.session.query(
            NewsStory,
            db.func.count(Feedback.id).label('feedback_count'),
            db.func.avg(Feedback.accuracy_rating).label('avg_accuracy'),
            db.func.avg(Feedback.bias_rating).label('avg_bias'),
            db.func.avg(Feedback.relevance_rating).label('avg_relevance'),
            db.func.avg(Feedback.local_impact_rating).label('avg_local_impact')
        ).outerjoin(Feedback).group_by(NewsStory.id).order_by(NewsStory.date_published.desc()).limit(10).all()

        # Category statistics
        category_stats = db.session.query(
            NewsStory.category,
            db.func.count(NewsStory.id).label('story_count'),
            db.func.count(Feedback.id).label('feedback_count')
        ).outerjoin(Feedback).group_by(NewsStory.category).all()

        # Region statistics
        region_stats = db.session.query(
            NewsStory.region,
            db.func.count(NewsStory.id).label('story_count'),
            db.func.count(Feedback.id).label('feedback_count')
        ).outerjoin(Feedback).group_by(NewsStory.region).all()

        return render_template('dashboard.html',
                             total_stories=total_stories,
                             total_feedback=total_feedback,
                             stories_with_feedback=stories_with_feedback,
                             category_stats=category_stats,
                             region_stats=region_stats)

    @app.route('/api/story/<int:story_id>/chart-data')
    def story_chart_data(story_id):
        """API endpoint for chart data"""
        story = NewsStory.query.get_or_404(story_id)
        feedbacks = Feedback.query.filter_by(story_id=story_id).all()
        insights = sentiment_analyzer.get_feedback_insights(feedbacks)

        return jsonify({
            'ratings': insights['avg_ratings'],
            'sentiment_distribution': insights['sentiment_distribution'],
            'total_feedback': insights['total_feedback']
        })

    @app.route('/import-csv', methods=['GET', 'POST'])
    def import_csv():
        """Import news stories from CSV file"""
        if request.method == 'POST':
            try:
                # Check if file was uploaded
                if 'csv_file' not in request.files:
                    flash('No file selected. Please choose a CSV file to upload.', 'error')
                    return redirect(request.url)

                file = request.files['csv_file']
                if file.filename == '':
                    flash('No file selected. Please choose a CSV file to upload.', 'error')
                    return redirect(request.url)

                # Validate file extension
                if not file.filename.lower().endswith('.csv'):
                    flash('Invalid file format. Please upload a CSV file.', 'error')
                    return redirect(request.url)

                # Read and parse CSV
                stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
                csv_reader = csv.DictReader(stream)

                # Validate required columns
                required_columns = ['title', 'content', 'author', 'publication', 'category', 'region']
                missing_columns = [col for col in required_columns if col not in csv_reader.fieldnames]

                if missing_columns:
                    flash(f'Missing required columns: {", ".join(missing_columns)}. Required columns are: {", ".join(required_columns)}', 'error')
                    return redirect(request.url)

                # Process CSV rows
                success_count = 0
                error_count = 0
                errors = []

                for row_num, row in enumerate(csv_reader, start=2):  # Start at 2 because row 1 is headers
                    try:
                        # Validate required fields
                        missing_fields = [field for field in required_columns if not row.get(field, '').strip()]
                        if missing_fields:
                            error_count += 1
                            errors.append(f'Row {row_num}: Missing required fields: {", ".join(missing_fields)}')
                            continue

                        # Check for duplicate story (by title and author)
                        existing_story = NewsStory.query.filter_by(
                            title=row['title'].strip(),
                            author=row['author'].strip()
                        ).first()

                        if existing_story:
                            error_count += 1
                            errors.append(f'Row {row_num}: Story "{row["title"]}" by {row["author"]} already exists')
                            continue

                        # Parse date if provided
                        date_published = datetime.utcnow()
                        if row.get('date_published', '').strip():
                            try:
                                # Try multiple date formats
                                date_str = row['date_published'].strip()
                                for date_format in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y-%m-%d %H:%M:%S']:
                                    try:
                                        date_published = datetime.strptime(date_str, date_format)
                                        break
                                    except ValueError:
                                        continue
                                else:
                                    # If no format worked, use current date and log warning
                                    logger.warning(f'Row {row_num}: Invalid date format "{date_str}", using current date')
                            except Exception as e:
                                logger.warning(f'Row {row_num}: Date parsing error: {e}')

                        # Create new story
                        story = NewsStory(
                            title=row['title'].strip(),
                            content=row['content'].strip(),
                            author=row['author'].strip(),
                            publication=row['publication'].strip(),
                            category=row['category'].strip(),
                            region=row['region'].strip(),
                            url=row.get('url', '').strip(),
                            image_url=row.get('image_url', '').strip(),
                            date_published=date_published
                        )

                        db.session.add(story)
                        success_count += 1

                    except Exception as e:
                        error_count += 1
                        errors.append(f'Row {row_num}: {str(e)}')
                        logger.error(f'Error processing row {row_num}: {e}')

                # Commit all successful imports
                if success_count > 0:
                    db.session.commit()
                    flash(f'Successfully imported {success_count} stories!', 'success')
                else:
                    db.session.rollback()

                # Report errors if any
                if error_count > 0:
                    error_summary = f'{error_count} rows had errors.'
                    if len(errors) <= 5:
                        error_details = ' Errors: ' + '; '.join(errors)
                    else:
                        error_details = f' First 5 errors: {"; ".join(errors[:5])}... and {len(errors) - 5} more.'
                    flash(error_summary + error_details, 'error')

                # Redirect to dashboard to see imported stories
                if success_count > 0:
                    return redirect(url_for('dashboard'))

            except Exception as e:
                logger.error(f"CSV import error: {e}")
                flash(f'Error processing CSV file: {str(e)}', 'error')
                db.session.rollback()

        return render_template('import_csv.html')

    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('500.html'), 500
