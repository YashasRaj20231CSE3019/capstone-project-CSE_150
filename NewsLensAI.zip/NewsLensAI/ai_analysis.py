from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import logging
import re

logger = logging.getLogger(__name__)

class SentimentAnalyzer:
    """Enhanced AI-powered sentiment analysis for feedback comments"""

    def __init__(self):
        self.vader_analyzer = SentimentIntensityAnalyzer()

    def analyze_sentiment(self, text):
        """
        Enhanced sentiment analysis using both VADER and TextBlob
        Returns: (score, label, confidence, details)
        """
        try:
            if not text or not text.strip():
                return 0.0, 'neutral', 0.0, {}

            # Clean text for better analysis
            cleaned_text = self._preprocess_text(text)

            # VADER analysis (better for social media style text)
            vader_scores = self.vader_analyzer.polarity_scores(cleaned_text)

            # TextBlob analysis (good for formal text)
            blob = TextBlob(cleaned_text)
            textblob_polarity = blob.sentiment.polarity
            textblob_subjectivity = blob.sentiment.subjectivity

            # Combine scores for more accurate analysis
            combined_score = (vader_scores['compound'] + textblob_polarity) / 2

            # Determine sentiment label with more nuanced thresholds
            if combined_score > 0.05:
                label = 'positive'
            elif combined_score < -0.05:
                label = 'negative'
            else:
                label = 'neutral'

            # Calculate confidence based on agreement between methods
            confidence = 1.0 - abs(vader_scores['compound'] - textblob_polarity) / 2

            details = {
                'vader_compound': vader_scores['compound'],
                'vader_positive': vader_scores['pos'],
                'vader_negative': vader_scores['neg'],
                'vader_neutral': vader_scores['neu'],
                'textblob_polarity': textblob_polarity,
                'textblob_subjectivity': textblob_subjectivity,
                'combined_score': combined_score
            }

            logger.debug(f"Enhanced sentiment: '{text[:50]}...' -> {combined_score:.3f} ({label}, conf: {confidence:.3f})")
            return combined_score, label, confidence, details

        except Exception as e:
            logger.error(f"Error in sentiment analysis: {e}")
            return 0.0, 'neutral', 0.0, {}

    def _preprocess_text(self, text):
        """Clean and preprocess text for better sentiment analysis"""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text.strip())

        # Handle common abbreviations and contractions
        text = text.replace("don't", "do not")
        text = text.replace("won't", "will not")
        text = text.replace("can't", "cannot")
        text = text.replace("n't", " not")
        text = text.replace("'re", " are")
        text = text.replace("'ve", " have")
        text = text.replace("'ll", " will")
        text = text.replace("'d", " would")

        return text

    def detect_bias_indicators(self, text):
        """
        Detect potential bias indicators in text
        Returns: dict with bias analysis
        """
        try:
            bias_indicators = {
                'loaded_language': self._detect_loaded_language(text),
                'emotional_language': self._detect_emotional_language(text),
                'absolute_terms': self._detect_absolute_terms(text),
                'bias_score': 0.0
            }

            # Calculate overall bias score
            bias_score = (
                bias_indicators['loaded_language']['score'] * 0.4 +
                bias_indicators['emotional_language']['score'] * 0.3 +
                bias_indicators['absolute_terms']['score'] * 0.3
            )

            bias_indicators['bias_score'] = round(bias_score, 3)

            return bias_indicators

        except Exception as e:
            logger.error(f"Error in bias detection: {e}")
            return {'bias_score': 0.0, 'error': str(e)}

    def _detect_loaded_language(self, text):
        """Detect loaded/charged language"""
        loaded_words = [
            'devastating', 'shocking', 'outrageous', 'incredible', 'amazing',
            'terrible', 'awful', 'fantastic', 'brilliant', 'disaster',
            'crisis', 'scandal', 'controversy', 'explosive', 'bombshell'
        ]

        text_lower = text.lower()
        found_words = [word for word in loaded_words if word in text_lower]
        score = min(len(found_words) / 10.0, 1.0)  # Normalize to 0-1

        return {
            'score': score,
            'found_words': found_words,
            'count': len(found_words)
        }

    def _detect_emotional_language(self, text):
        """Detect highly emotional language"""
        # Use VADER to detect emotional intensity
        scores = self.vader_analyzer.polarity_scores(text)
        emotional_intensity = max(scores['pos'], scores['neg'])

        return {
            'score': emotional_intensity,
            'intensity': 'high' if emotional_intensity > 0.7 else 'medium' if emotional_intensity > 0.4 else 'low'
        }

    def _detect_absolute_terms(self, text):
        """Detect absolute terms that may indicate bias"""
        absolute_terms = [
            'always', 'never', 'all', 'none', 'every', 'completely',
            'totally', 'absolutely', 'definitely', 'certainly', 'obviously',
            'clearly', 'undoubtedly', 'without question'
        ]

        text_lower = text.lower()
        found_terms = [term for term in absolute_terms if term in text_lower]
        score = min(len(found_terms) / 5.0, 1.0)  # Normalize to 0-1

        return {
            'score': score,
            'found_terms': found_terms,
            'count': len(found_terms)
        }
    
    def get_feedback_insights(self, feedbacks):
        """
        Analyze multiple feedback entries to provide insights
        """
        if not feedbacks:
            return {
                'total_feedback': 0,
                'avg_sentiment': 0.0,
                'sentiment_distribution': {'positive': 0, 'negative': 0, 'neutral': 0},
                'avg_ratings': {'accuracy': 0, 'bias': 0, 'relevance': 0, 'local_impact': 0}
            }
        
        # Calculate averages
        total_count = len(feedbacks)
        sentiment_sum = sum(f.sentiment_score or 0 for f in feedbacks)
        avg_sentiment = sentiment_sum / total_count if total_count > 0 else 0
        
        # Sentiment distribution
        sentiment_dist = {'positive': 0, 'negative': 0, 'neutral': 0}
        for feedback in feedbacks:
            label = feedback.sentiment_label or 'neutral'
            sentiment_dist[label] = sentiment_dist.get(label, 0) + 1
        
        # Average ratings
        avg_ratings = {
            'accuracy': sum(f.accuracy_rating for f in feedbacks) / total_count,
            'bias': sum(f.bias_rating for f in feedbacks) / total_count,
            'relevance': sum(f.relevance_rating for f in feedbacks) / total_count,
            'local_impact': sum(f.local_impact_rating for f in feedbacks) / total_count
        }
        
        return {
            'total_feedback': total_count,
            'avg_sentiment': round(avg_sentiment, 3),
            'sentiment_distribution': sentiment_dist,
            'avg_ratings': {k: round(v, 2) for k, v in avg_ratings.items()}
        }
